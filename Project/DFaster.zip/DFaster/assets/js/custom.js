//js code for mobile menu 
      // $('.navbar-toggle').on('click', function(e) {
      //   $('body').toggleClass('open-mobile-menu')
      // });

      // $('.mobile-menu>ul>li>a,.mobile-menu ul.mobile-submenu>li>a').on('click', function(e) {
      //   var element = $(this).parent('li');
      //   if (element.hasClass('open')) {
      //     element.removeClass('open');
      //     element.find('li').removeClass('open');
      //     element.find('ul').slideUp(1500,"swing");
      //   }
      //   else {
      //     element.addClass('open');
      //     element.children('ul').slideDown(1500,"swing");
      //     element.siblings('li').children('ul').slideUp(1500,"swing");
      //     element.siblings('li').removeClass('open');
      //     element.siblings('li').find('li').removeClass('open');
      //     element.siblings('li').find('ul').slideUp(1500,"swing");
      //   }
      // });



var swiper = new Swiper('.testimonial-container', {
  slidesPerView: 3,
  spaceBetween: 30,
  slidesPerGroup: 1,
  loop: true,
  loopFillGroupWithBlank: true,
  paginationClickable: true,
  centeredSlides: true,
  autoplay: {
    delay: 1500,
    disableOnInteraction: false,
  },
  pagination: {
    el: '.swiper-pagination',
    clickable: true,
  },
  breakpoints: {
    1024: {
      slidesPerView: 3,
      spaceBetween: 40,
    },
    990: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    600: {
      slidesPerView: 1,
      spaceBetween: 10,
    }
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});